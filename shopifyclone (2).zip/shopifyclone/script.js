console.log("welcome spotify");

// Initialized the variable
let songIndex = 0;
let audioElement = new Audio('song/kash.mp3');
let masterplay = document.getElementById("masterPlay");
let myprogresbar = document.getElementById("myprogresbar");
let gif = document.getElementById("gif");
let prevButton = document.getElementById("previous");
let nextButton = document.getElementById("next");
let songItems = Array.from(document.getElementsByClassName("songItem"));
let mastersongname=document.getElementById("edit");
let songs = [

    { songname: "kash", filePath: "song/kash.mp3", coverPath: "img/kash.jpeg" },
    { songname: "sajna", filePath: "song/sajna.mp3", coverPath: "img/sajna.jpg" },
    { songname: "jism", filePath: "song/jism.mp3", coverPath: "img/jism.jpeg" },
    { songname: "sajna2", filePath: "song/sajna2.mp3", coverPath: "img/sajna.jpg" },
    { songname: "kash", filePath: "song/kash.mp3", coverPath: "img/cover.jpg" },
    { songname: "kash", filePath: "song/kash.mp3", coverPath: "img/cover.jpg" },
];

songItems.forEach((element, i) => {
    element.getElementsByTagName("img")[0].src = songs[i].coverPath;
    element.getElementsByClassName("songname")[0].innerHTML = songs[i].songname;
});

// masterplay button event
masterplay.addEventListener('click', () => {
    if (audioElement.paused || audioElement.currentTime <= 0) {
        audioElement.play();
        masterplay.classList.remove('fa-play-circle');
        masterplay.classList.add('fa-pause-circle');
        gif.style.opacity = 1;
    } else {
        audioElement.pause();
        masterplay.classList.remove('fa-pause-circle');
        masterplay.classList.add('fa-play-circle');
        gif.style.opacity = 0;
    }
});

// listen event
audioElement.addEventListener('timeupdate', () => {
    // update seekbar
    let progress = parseInt((audioElement.currentTime / audioElement.duration) * 100);
    myprogresbar.value = progress;
});

// update seek bar
myprogresbar.addEventListener('change', () => {
    audioElement.currentTime = myprogresbar.value * audioElement.duration / 100;
});

const makeAllPlays = () => {
    Array.from(document.getElementsByClassName('songitemplay')).forEach((element) => {

        element.classList.remove("fa-pause-circle");
        element.classList.add("fa-play-circle");
    });
};

Array.from(document.getElementsByClassName('songitemplay')).forEach((element, i) => {
    element.addEventListener('click', (e) => {
        if (songIndex === i && !audioElement.paused) {
            return; // If the same song is already playing, don't do anything
        }
        makeAllPlays();
        songIndex = i;
        e.target.classList.remove('fa-play-circle');
        e.target.classList.add('fa-pause-circle');
        audioElement.src = songs[songIndex].filePath;
        audioElement.currentTime = 0;
        audioElement.play();
        mastersongname.innerText=songs[songIndex].songname;
        masterplay.classList.remove('fa-play-circle');
        masterplay.classList.add('fa-pause-circle');
    });
});


nextButton.addEventListener('click', () => {
    songIndex = (songIndex + 1) % songs.length;
    audioElement.src = songs[songIndex].filePath;
    audioElement.currentTime = 0;
    audioElement.play();
    mastersongname.innerText=songs[songIndex].songname;
    masterPlay.classList.replace('fa-play-circle', 'fa-pause-circle');
});

// Previous song
prevButton.addEventListener('click', () => {
    songIndex = (songIndex - 1 + songs.length) % songs.length;
    audioElement.src = songs[songIndex].filePath;
    audioElement.currentTime = 0;
    audioElement.play();
    mastersongname.innerText=songs[songIndex].songname;
    masterPlay.classList.replace('fa-play-circle', 'fa-pause-circle');
});